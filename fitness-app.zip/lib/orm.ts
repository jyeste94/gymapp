export const epley = (w:number, r:number) => w * (1 + r/30);
export const brzycki = (w:number, r:number) => w * (36/(37 - r));
