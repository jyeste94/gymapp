export default function RoutinesPage() {
  return (
    <div className="rounded-2xl border p-4">
      <h3 className="font-semibold">Rutinas</h3>
      <p className="text-sm text-zinc-600">Builder drag & drop con @dnd-kit (pendiente de completar).</p>
    </div>
  );
}
